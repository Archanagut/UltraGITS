<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 offset-lg-2">
        <div class="site-heading text-center">
          <h4 class="sub-title">Success in Numbers</h4>
          <h2 class="title"><strong>Our Achievements</strong></h2>
          <div class="devider"></div>
        </div>
      </div>
    </div>
    <div class="row">
      <!-- Happy Clients -->
      <div class="col-6 col-md-3 mb-4">
        <div class="counter-box text-center">
          <i class="fas fa-smile-beam fa-3x mb-3 text-success animated-icon"></i>
          <h3><span class="counter" data-target="300">0</span><strong>+</strong></h3>
          <p><strong>Happy Clients</strong></p>
        </div>
      </div>
      <!-- Projects -->
      <div class="col-6 col-md-3 mb-4">
        <div class="counter-box text-center">
          <i class="fas fa-tasks fa-3x mb-3 text-primary animated-icon"></i>
          <h3><span class="counter" data-target="500">0</span><strong>+</strong></h3>
          <p><strong>Projects</strong></p>
        </div>
      </div>
      <!-- Certified Experts -->
      <div class="col-6 col-md-3 mb-4">
        <div class="counter-box text-center">
          <i class="fas fa-user-check fa-3x mb-3 text-warning animated-icon"></i>
          <h3><span class="counter" data-target="15">0</span><strong>+</strong></h3>
          <p><strong>Certified Experts</strong></p>
        </div>
      </div>
      <!-- Satisfaction -->
      <div class="col-6 col-md-3 mb-4">
        <div class="counter-box text-center">
          <i class="fas fa-star fa-3x mb-3 text-danger animated-icon"></i>
          <h3><span class="counter" data-target="100">0</span><strong>%</strong></h3>
          <p><strong>Satisfaction</strong></p>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  .counter-box {
    text-align: center; /* Center the text and icons */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 20px;
    /* Removed border, background, border-radius, and shadow to make it simpler */
  }

  .counter-box i {
    margin-bottom: 15px; /* Space between the icon and the text */
  }

  .counter-box h3 {
    font-size: 36px; /* Size of the counter number */
    font-weight: bold;
    color: #333;
  }

  .counter-box p {
    font-size: 16px;
    color: #555;
    font-weight: 600;
  }

  .counter-box strong {
    font-weight: bold;
  }

  .site-heading h4.sub-title {
    font-size: 20px;
    color: #888; /* Greyish color */
    font-weight: normal;
  }

  .site-heading h2.title {
    font-size: 32px;
    font-weight: bold;
    color: #333; /* Dark color */
  }

  .site-heading .devider {
    width: 50px;
    height: 3px;
    background-color: #007bff; /* Blue color */
    margin: 20px auto;
  }
</style>
