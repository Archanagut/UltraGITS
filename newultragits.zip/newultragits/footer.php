
    <!-- Start Footer
    ============================================= -->
    <footer class="bg-dark text-light" style="background-image: url(assets/img/shape/35.png);">
        <div class="container">
            <div class="f-items default-padding">
                <div class="row">
                    <div class="col-lg-4 col-md-6 footer-item pr-50 pr-xs-15 pr-md-15">
                        <div class="about">
                            <img class="logo" src="assets/img/image.png" alt="Logo">
                            <p>
                                Excellence decisively nay man per impression maximum contrasted remarkably is perfect point. uncommonly solicitude inhabiting projection.
                            </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-item">
                        <div class="link">
                            <h4 class="widget-title">Our Services</h4>
                            <ul>
                                <li>
                                    <a href="services-details.html">Digital Marketing </a>
                                </li>
                                <li>
                                    <a href="services-details.html">App Development</a>
                                </li>
                                <li>
                                    <a href="services-details.html">Website Development</a>
                                </li>
                                <li>
                                    <a href="services-details.html">Custom ERP Software</a>
                                </li>
                                <li>
                                    <a href="services-details.html">Social Media Marketing</a>
                                </li>

                                <li>
                                    <a href="services-details.html">Web Application  </a>
                                </li>

                                <li>
                                    <a href="services-details.html">SEO,SMM,SEM</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 footer-item adress-item">
                        <h4 class="widget-title">Official Info</h4>
                        <div class="address">
                            <ul>
                                <li>
                                    <div class="content">
                                        <strong>Address:</strong> Faiz Manzil, 10/44, Aziz Mulk 1st St,
                                        Thousand Lights, Chennai,
                                        Tamil Nadu 600006
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <strong>Email:</strong>
                                        <a href="mailto:mail@ultragits.com">mail@ultragits.com</a>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <strong>Phone:</strong>
                                        <a href="tel: +91-8610213611"> +91-8610213611</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 footer-item">
                        <h4 class="widget-title">Newsletter</h4>
                        <div class="newsletter">
                            <p>
                                Join our subscribers list to get the latest news and special offers.
                            </p>
                            <form action="#">
                                <input type="email" placeholder="Your Email"  class="form-control" name="email">
                                <button type="submit" name="submit" id="submit" style="background-color: #1e3a74;"> Subscribe Now <i class="fa fa-paper-plane" ></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom bg-dark-secondary">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <p>&copy; Copyright 2025.Developed By   <a href="https://www.ultragits.com/">UltraGITS Team</a></p>
                    </div>
                    <div class="col-lg-6 text-end">
                        <ul>
                            <li>
                                <a href="terms-conditions.php">Terms & Conditions</a>
                            </li>
                            <li>
                                <a href="privacy-policy.php">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="contact-us.php">Support</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
    <!-- End Footer -->

   <!-- Sticky Left Call & WhatsApp -->
<div class="left-sticky animate-slide-in">
  <ul>
    <li>
      <a href="tel:+918610213611" target="_blank" title="Call Us" class="icon-hover">
        <i class="fas fa-headset"></i>
      </a>
    </li>
    <li>
      <a href="https://wa.me/918610213611" target="_blank" title="WhatsApp Us" class="icon-hover">
        <i class="fab fa-whatsapp"></i>
      </a>
    </li>
  </ul>
</div>



<!-- CSS -->
<style>
  .left-sticky {
    position: fixed;
    top: 40%;
    left: 0;
    z-index: 9999;
    background-color: #1e3974;
    border-radius: 0 8px 8px 0;
    opacity: 0;
    transform: translateX(-100%);
    animation: slideInLeft 1s ease forwards;
  }

  .left-sticky ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .left-sticky ul li {
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  }

  .left-sticky ul li:last-child {
    border-bottom: none;
  }

  .left-sticky ul li a {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 14px 16px;
    color: white;
    font-size: 18px;
    text-decoration: none;
    transition: background 0.3s;
  }

  .left-sticky ul li a:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }

  /* Slide In Animation */
  @keyframes slideInLeft {
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  /* Icon Hover Animation */
  .icon-hover i {
    transition: transform 0.3s ease;
  }

  .icon-hover:hover i {
    transform: scale(1.2) rotate(10deg);
  }
</style>
