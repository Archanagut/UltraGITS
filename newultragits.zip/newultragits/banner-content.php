 <!-- Start Banner Area
    ============================================= -->
    <!-- <div class="banner-style-one-area overflow-hidden text-light"
     style="background-image: url('https://t3.ftcdn.net/jpg/03/51/15/08/360_F_351150802_VAlf5qCG8jhHdMG75g2EoqHBwV0CSfSo.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;"> -->



        <!-- Single Item -->
        <!-- <div class="banner-style-one">
            <div class="container">
                <div class="content">
                    <div class="row align-center">
                        <div class="col-xl-6 col-lg-6">
                            <div class="info pr-35 pr-xs-0 pr-md-0">
                                <h4>Grow your business with us</h4>
                                <h2>Top Digital Marketing Company In Chennai </h2>
                                <p>
                                    We are a team of seasoned experts with over 10 years of experience in the <b>digital marketing in chennai</b>. We specialize in delivering top-quality IT software and hardware solutions, covering everything from core design to comprehensive online marketing strategies.
                                </p>
                                <div class="button">
                                    <a class="btn btn-md btn-theme animation" style="background-color:#20377B;" href="contact-us.php">Get A Proposal</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-6">
                            <div class="thumb"> -->
                                <!-- <img src="assets/img/illustration/8.png" alt="Thumb"> -->
                            <!-- </div>
                        </div>

                    </div>
                </div>
            </div> -->
            <!-- <div class="shape-bottom-center" style="background-image: url('assets/img/shape/5.png');"></div>
            <div class="shape-top-right" style="background-image: url(assets/img/shape/6.png);"></div> -->

        <!-- </div> -->
        <!-- End Single Item -->
    <!-- </div> -->
    <!-- End Banner -->



     <!-- Start Banner Area
    ============================================= -->
    <div class="banner-style-five-area bg-cover" style="background-image: url(assets/img/banner.jpg);">

<!-- Single Item -->
<div class="banner-style-five">
    <div class="container">
        <div class="content">
            <div class="row align-center">
                <div class="col-xl-6 col-lg-7">
                    <div class="info pr-35 pr-xs-0 pr-md-0">
                        <h1>Best Digital Marketing Agency <strong>In Chennai </strong>
                        </h1>
                        <p>
                            We’re a values-driven company that provides affordable, digital marketing   for ambitious people and teams.
                        </p>
                        <div class="button mt-30">
                            <a class="btn btn-md   animation" style="background-color: #1e3974; color:white;" href="contact-us.php">Get in touch</a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-5 pl-60 pl-md-15 pl-xs-15 mt-md-80">
                    <div class="banner-style-five-thumb">
                        <img src="assets/img/8.jpg" alt="Thumb">
                        <img src="assets/img/7.jpg" alt="Thumb">
                        <img src="assets/img/9.jpg" alt="Thumb">
                        <div class="shape">
                            <img src="assets/img/17.png" alt="Image Not Found">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Single Item -->
</div>
<!-- End Banner -->