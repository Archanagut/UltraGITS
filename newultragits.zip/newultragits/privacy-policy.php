<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Privacy Policy  | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->


</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Preloader
    ============================================= -->



    <!-- Header
    ============================================= -->
    <header>
<?php include 'header.php' ?>


    </header>


    <div class="breadcrumb-area text-center" style=" background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">

<div class="container">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <h1>Privacy Policy</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Privacy Policy</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
</div>

<div style="max-width: 90%; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 12px; background-color: #fdfdfd;">
    <h3><b>1. Consent</b>   </h3>
    <p>By using our website, you hereby consent to our Privacy Policy and agree to its terms.</p>
    <p>This policy applies only to our online activities and is valid for visitors to our website with regard to the information that they shared or collected in UltraGITS.</p>

    <h3><b>2. Information We Collect</b></h3>
    <p>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.</p>
    <p>Name, email, phone number, and other contact details if you contact us directly.</p>
    <p>Name, address, and other personal details if you register for an account.</p>

    <h3><b>3. How We Use Your Information</b></h3>
    <p>We use the information we collect in various ways, including to:</p>
    <p>Provide, operate, and maintain our website.</p>
    <p>Improve, personalize, and expand our website.</p>
    <p>Understand and analyze how you use our website.</p>
    <p>Communicate with you for updates, promotions, and marketing.</p>
    <p>Prevent fraud and security issues.</p>

    <h3><b>4. Log Files</b></h3>
    <p>UltraGITS follows a standard procedure of using log files. These files include:</p>
    <p>IP addresses</p>
    <p>Browser type</p>
    <p>Internet Service Provider (ISP)</p>
    <p>Page timestamps and referring/exit pages</p>
    <p>This data is used for analyzing trends, administering the site, tracking users' movement on the website, and gathering demographic information.</p>

    <h3><b>5. Cookies and Web Beacons</b></h3>
    <p>We use cookies to store information about visitors' preferences and enhance their experience. Cookies help us:</p>
    <p>Personalize content based on your browsing habits.</p>
    <p>Improve site performance and user experience.</p>

    <h3><b>6. Third Party Privacy Policies</b></h3>
    <p>UltraGITS’s Privacy Policy does not apply to other advertisers or third-party websites.</p>
    <p>Please refer to their respective privacy policies for more detailed information on how they handle your data.</p>

    <h3><b>7. CCPA Privacy Rights</b></h3>
    <p>Under the CCPA, California consumers have the right to:</p>
    <p>Request disclosure of the categories and pieces of personal data we've collected.</p>
    <p>Request deletion of any personal data we've collected.</p>
    <p>Opt-out of the sale of personal data.</p>
    <p>If you wish to exercise these rights, please contact us within one month.</p>

    <h3><b>8. GDPR Data Protection Rights</b></h3>
    <p>Under GDPR, users are entitled to the following data protection rights:</p>
    <p>The right to access.</p>
    <p>The right to rectification.</p>
    <p>The right to erasure.</p>
    <p>The right to restrict processing.</p>
    <p>The right to object to processing.</p>
    <p>The right to data portability.</p>
    <p>Contact us within one month to exercise these rights.</p>

    <h3><b>9. Children's Information</b></h3>
    <p>We do not knowingly collect personal information from children under the age of 13.</p>
    <p>If you believe we have, please contact us immediately to remove such information.</p>
</div>



<?php include 'footer.php' ?>
    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>